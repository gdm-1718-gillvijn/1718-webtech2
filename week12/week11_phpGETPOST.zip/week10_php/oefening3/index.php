<?php
    require 'header.php';
?>

    <div id= "content">
    Dit is de content van de homepagina
    </div>

<?php
    require 'footer.php';
?>