<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width= , initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    body {
        background: black;
        color: white;
        font-size: 20px;
        text-align: center;
        padding-top: 200px;
        }
        </style>
</head>
<body>


<form method="GET" action="results.php">
<input name="zoekveld" type="search" placeholder="Search the interwebz">
<button type="submit">Go wild</button>
</form>  


</body>
</html>